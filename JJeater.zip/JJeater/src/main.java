import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.util.regex.*;
public class main extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					main frame = new main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	//int indicesSociales = 0;

     
     String nextLine = " ";
     File myObj = new File("tweets.txt");
     
     JJobject Tweet = new JJobject(myObj, "\"");
     
     private int countIndicesSociales(String word) {
    	 int indicesSociales = 0;
		 int blockCounter = 0;
		 int pos = 0;
		 int end = 0;
    	 try {
			 Scanner myReader = new Scanner(myObj);
			
			 
			
				 
				 //myReader.nextLine();
				
	    	  		//StringBuilder content= new StringBuilder();	
	    	  		// Pattern pattern = Pattern.compile("word");
			 
			
				
				
			    	
					while((myReader.hasNextLine())) {
						
						 nextLine = myReader.nextLine();				    		  
					    	
		    	  			if(nextLine.contains("indices")) {
		    	  				
		    	  				blockCounter++;
		    	  				//match.start();
		    	  				//match.end();
		    	  				//nextLine = nextLine.replaceAll("\\D", ""); 
		    	  					int indice = 0;	 					    		 
		    	  					 nextLine = myReader.nextLine();
		    	  					 nextLine = nextLine.replaceAll("\\D", ""); 
							    	
							    		  try {
							    			 indice= Integer.parseInt(nextLine);
							    			 System.out.println(nextLine);
							    			 
							    		  }catch(Exception e1){
							    			  System.out.println(e1);
							    			  indice = 0;
							    		  }		
							    		  
							    		  indicesSociales+= indice;								    		  							    		  
							    		  nextLine = myReader.nextLine();
							    		  
							    		  nextLine = nextLine.replaceAll("\\D", ""); 
									    	
							    		  try {
							    			  indice = Integer.parseInt(nextLine);
							    			  System.out.println(nextLine);
							    		  }catch(Exception e1) {
							    			  System.out.println(e1);
							    			  indice = 0;
							    		  }					    		  
							    		  indicesSociales+= indice;
							    		  
							    		  break;
							    		  //nextLine = myReader.nextLine();
							    		 
							    		 // System.out.println("position: "+end);
							    		// content.setLength(0);
							    	  }  
		    	  			 nextLine = nextLine.replaceAll("indices", "X");	
				 	
			 }
			 myReader.close();	
		    } catch (Exception e1) {
		    	 e1.printStackTrace();   
		    }
    	 
		 
 	  	System.out.println("blocks scanned: "+blockCounter);	    	  	
 	  	System.out.println();
    	 return indicesSociales;
     }
     
	public main() {
		 
		 try {	     
			
		    
		  				    	     
		    } catch (Exception e2) {		    	
		    	System.out.println(e2);	     
		    }	
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Indices: ");
		lblNewLabel.setFont(new Font("Comic Sans MS", Font.ITALIC, 16));
		lblNewLabel.setForeground(new Color(100, 149, 237));
		lblNewLabel.setBounds(55, 24, 97, 32);
		contentPane.add(lblNewLabel);
		
		JLabel lblVarInd = new JLabel("0");
		lblVarInd.setForeground(new Color(60, 179, 113));
		lblVarInd.setFont(new Font("Comic Sans MS", Font.BOLD, 16));
		lblVarInd.setBounds(160, 27, 276, 32);
		contentPane.add(lblVarInd);
		
		
		
		JButton btnNewButton = new JButton("Load File");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				lblVarInd.setText(Integer.toString(countIndicesSociales("indices")));
				
				
				 
				  
			}
		});
		btnNewButton.setBounds(55, 66, 114, 21);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("stop");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//myReader.close();
			}
		});
		btnNewButton_1.setBounds(74, 113, 81, 21);
		contentPane.add(btnNewButton_1);
	}
}

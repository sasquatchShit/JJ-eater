import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class JJobject {
	
	private String name;
	
	ArrayList<String> vars;
	File file;
	
	public JJobject(File file, String name) {
		this.setName(name);
		this.file = file;
		vars = new ArrayList<String>();
		
		System.out.println(file.getName()+" has "+countVar(name)+" objects of ' "+getName()+" ' type");		
	}

	public int countVar(String name) {
   	 int instances = 0;
   	 Scanner myReader = null;
   	//String nextLine = " ";
   	 int lines = 0;
   	 
		 try {		
			 
			myReader = new Scanner(file);
			
			
			while(myReader.hasNextLine()) {
				lines++;
				String nextLine = myReader.nextLine();
				System.out.println(nextLine);
				if(nextLine.contains(name)) {
							
					instances++;
					
				}	
			}
			System.out.println("countVar has sniffed "+lines+" lines");
			
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		myReader.close();
		return instances;
    }
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
